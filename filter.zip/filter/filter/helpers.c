#include "helpers.h"
#include "math.h"
#include "stdio.h"
// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{   
    int gray;
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {   
            gray = round((image[i][j].rgbtBlue + image[i][j].rgbtGreen + image[i][j].rgbtRed) / 3.0);
            image[i][j].rgbtBlue = gray;
            image[i][j].rgbtGreen = gray;
            image[i][j].rgbtRed = gray;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{   RGBTRIPLE temp[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            temp[i][j].rgbtBlue = image[i][width-(j+1)].rgbtBlue;
            temp[i][j].rgbtGreen = image[i][width-(j+1)].rgbtGreen;
            temp[i][j].rgbtRed = image[i][width-(j+1)].rgbtRed;
        }
        
        for (int j = 0; j < width; j++)
        {
            image[i][j].rgbtBlue = temp[i][j].rgbtBlue;
            image[i][j].rgbtGreen = temp[i][j].rgbtGreen;
            image[i][j].rgbtRed = temp[i][j].rgbtRed;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{   
    RGBTRIPLE temp[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {   
            double count = 0.0;
            int sumBlue = 0;
            int sumGreen = 0;
            int sumRed = 0;
            for (int k = -1; k < 2; k++)
            {
                for (int l = -1; l < 2; l++)
                {
                    if (((i + k) > -1) && ((i+k) < height) && ((j+l) > -1) && ((j+l) < width))
                    {   
                        sumBlue += image[i+k][j+l].rgbtBlue;
                        sumGreen += image[i+k][j+l].rgbtGreen;
                        sumRed += image[i+k][j+l].rgbtRed;
                        count++;
                    }
                }
            }
            
            sumBlue = round(sumBlue / count);
            sumGreen = round(sumGreen / count);
            sumRed = round(sumRed / count);
            temp[i][j].rgbtBlue = (int) sumBlue;
            temp[i][j].rgbtGreen = (int) sumGreen;
            temp[i][j].rgbtRed = (int) sumRed;
        }
    }   
    

        for (int i = 0; i < height; i++)
        {
            for (int j = 0; j < width; j++)
            {   
                
                image[i][j].rgbtBlue = temp[i][j].rgbtBlue;
                image[i][j].rgbtGreen = temp[i][j].rgbtGreen;
                image[i][j].rgbtRed = temp[i][j].rgbtRed;
            }
        }
    
    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{   
    RGBTRIPLE temp[height][width];
    
    int G_X[3][3] = {{-1, 0, 1},{-2, 0, 2},{-1, 0, 1}};
    int G_Y[3][3] = {{-1, -2, -1},{0, 0, 0}, {1, 2, 1}};
    int X_count;
    int Y_count;
    int sumBlue_X;
    int sumGreen_X;
    int sumRed_X;
    int sumBlue_Y;
    int sumGreen_Y;
    int sumRed_Y;
    
    // values for each pixel for all channels
    int totalRed;
    int totalBlue;
    int totalGreen;
    
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {   
            // G_X and G_Y elements
            X_count = 0;
            Y_count = 0;
            // X values
            sumBlue_X = 0;
            sumGreen_X = 0;
            sumRed_X = 0;
            // Y values
            sumBlue_Y = 0;
            sumGreen_Y = 0;
            sumRed_Y = 0;
            
            totalRed = 0;
            totalBlue = 0;
            totalGreen = 0;
            for (int k = -1; k < 2; k++)
            {   
                X_count = k+1;
                for (int l = -1; l < 2; l++)
                {   
                    Y_count = l+1;
                    // If within bounds use the pixel value
                    if (((i + k) > -1) && ((i+k) < height) && ((j+l) > -1) && ((j+l) < width))
                    {
                        sumRed_X += G_X[X_count][Y_count] * image[i+k][j+l].rgbtRed;
                        sumBlue_X += G_X[X_count][Y_count] * image[i+k][j+l].rgbtBlue;
                        sumGreen_X += G_X[X_count][Y_count] * image[i+k][j+l].rgbtGreen;
                        
                        sumRed_Y += G_Y[X_count][Y_count] * image[i+k][j+l].rgbtRed;
                        sumBlue_Y += G_Y[X_count][Y_count] * image[i+k][j+l].rgbtBlue;
                        sumGreen_Y += G_Y[X_count][Y_count] * image[i+k][j+l].rgbtGreen;
                    }
                    else
                    {
                        sumRed_X += G_X[X_count][Y_count] * 0;
                        sumBlue_X += G_X[X_count][Y_count] * 0;
                        sumGreen_X += G_X[X_count][Y_count] * 0;
                        
                        sumRed_Y += G_Y[X_count][Y_count] * 0;
                        sumBlue_Y += G_Y[X_count][Y_count] * 0;
                        sumGreen_Y += G_Y[X_count][Y_count] * 0;
                    }
                }
            }
            
            totalRed = round(sqrt((pow(sumRed_X,2) + pow(sumRed_Y,2))));
            totalBlue = round(sqrt((pow(sumBlue_X,2) + pow(sumBlue_Y,2))));
            totalGreen = round(sqrt((pow(sumGreen_X,2) + pow(sumGreen_Y,2))));
            
            //Red Value
            if (totalRed <= 255)
            {
                temp[i][j].rgbtRed = totalRed;
            }
            else
            {
                temp[i][j].rgbtRed = 255;
            }
            
            //Blue Value
            if (totalBlue <= 255)
            {
                temp[i][j].rgbtBlue = totalBlue;
            }
            else
            {
                temp[i][j].rgbtBlue = 255;
            }
            
            //Green Value
            if (totalGreen <= 255)
            {
                temp[i][j].rgbtGreen = totalGreen;
            }
            else
            {
                temp[i][j].rgbtGreen = 255;
            }
        }
    }
    

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {   
            image[i][j].rgbtBlue = temp[i][j].rgbtBlue;
            image[i][j].rgbtGreen = temp[i][j].rgbtGreen;
            image[i][j].rgbtRed = temp[i][j].rgbtRed;
        }
    }
    return;
}
